package com.QuickOrder.FixNow.Model;

public enum TipoPedido {
    DELIVERY,
    RETIRO_EN_TIENDA,
    EXPRESS
}

//En TipoPedido definí los 3 modos de entrega al cliente que puede estar el pedido
package com.QuickOrder.FixNow.Service;

import com.QuickOrder.FixNow.Model.Estado;
import com.QuickOrder.FixNow.Model.Pedido;
import com.QuickOrder.FixNow.Repository.PedidoRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class

PedidoService {
    private final PedidoRepository repository;
    public PedidoService(PedidoRepository repository) { this.repository = repository; }

    public List<Pedido> listarTodos() { return repository.findAll(); } // Aqui obtengo los datos desde el Repository

    public Pedido crear(Pedido pedido) {
        if (pedido.getMontoTotal() <= 0) return null; // Validación simple, el monto debe ser mayor que 0 y que si no devuelva un nulo
        pedido.setFechaPedido(LocalDate.now());
        return repository.save(pedido);
    }
    public Pedido buscarPorId(Long id) {
        return repository.findById(id).orElse(null); } // Busco el pedido por su id y si esta correcto me entrega los datos desde el repositorio

    public boolean eliminar(Long id) { return repository.delete(id); }

    public List<Pedido> filtrarPorEstado(Estado estado) {
        return repository.findAll().stream().filter(p ->p.getEstado() == estado) .collect(Collectors.toList());
    }
}

//En esta clase se hacen las validaciones.
package com.QuickOrder.FixNow.Model;

public enum Estado {
    PENDIENTE,
    EN_PREPARACION,
    EN_CAMINO,
    ENTREGADO,
    CANCELADO
}

// Dentro de Estado, definí los 5 posibles estados por los que pasan los pedidos de soporte de la empresa
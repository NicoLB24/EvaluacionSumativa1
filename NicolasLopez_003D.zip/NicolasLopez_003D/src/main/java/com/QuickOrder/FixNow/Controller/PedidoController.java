package com.QuickOrder.FixNow.Controller;


import com.QuickOrder.FixNow.Model.Estado;
import com.QuickOrder.FixNow.Model.Pedido;
import com.QuickOrder.FixNow.Service.PedidoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pedidos")

public class PedidoController {
    private final PedidoService service;

    public PedidoController(PedidoService service) { this.service = service; }

    @GetMapping
    public List<Pedido> getAll() { return service.listarTodos(); } //Con esta funcion le pido que me devuelva los datos de la lista completa que tengo

    @PostMapping
    public ResponseEntity<Pedido> add(@RequestBody Pedido pedido) {
        Pedido nuevo = service.crear(pedido);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    } // Sirve para registrar un nuevo dato, en este caso un nuevo pedido, en el que debo incluir todos los datos necesarios para que funcione correctamente el registro

    @GetMapping("/{id}")
    public ResponseEntity<Pedido> getById(@PathVariable Long id) {
        Pedido p = service.buscarPorId(id);
        return p != null ? new ResponseEntity<>(p, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    } // Tambien entrega los datos de pedidos pero solo el que especificamente se este pidiendo, por ejemplo el 1

    @DeleteMapping("/{id}")
    public ResponseEntity<Pedido> delete(@PathVariable Long id) {
        return service.eliminar(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    } // Sirve para eliminar los datos de un pedido especifico indicando el id del mismo

    @GetMapping("/estado/{estado}")
    public List<Pedido> getEstado(@PathVariable Estado estado) {
        return service.filtrarPorEstado(estado);
    }
} // sirve para retornar pedidos pero con el filtro de que solo se vean segun un estado, por ejemplo ENTREGADO

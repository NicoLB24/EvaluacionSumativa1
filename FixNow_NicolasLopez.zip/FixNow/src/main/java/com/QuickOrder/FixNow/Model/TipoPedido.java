package com.QuickOrder.FixNow.Model;

public enum TipoPedido {
    DELIVERY,
    RETIRO_EN_TIENDA,
    EXPRESS
}

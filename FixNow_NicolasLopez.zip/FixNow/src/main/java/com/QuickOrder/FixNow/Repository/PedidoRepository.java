package com.QuickOrder.FixNow.Repository;

import com.QuickOrder.FixNow.Model.Pedido;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

@Repository
public class PedidoRepository {
    private List<Pedido> pedidos = new ArrayList<>();
    private Long idContator = 1L;

    public List<Pedido> findAll() {
        return pedidos;
    }

    public Pedido save(Pedido pedido) {
        pedido.setId(idContator++);
        pedidos.add(pedido);
        return pedido;
    }

    public Optional<Pedido> findById(Long id) {
        return pedidos.stream().filter(p -> p.getId().equals(id)).findFirst();
    }

    public boolean delete(Long id) {
        return pedidos.removeIf(p -> p.getId().equals(id));
    }
}
package com.QuickOrder.FixNow.Controller;


import com.QuickOrder.FixNow.Model.Estado;
import com.QuickOrder.FixNow.Model.Pedido;
import com.QuickOrder.FixNow.Service.PedidoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pedidos")

public class PedidoController {
    private final PedidoService service;

    public PedidoController(PedidoService service) { this.service = service; }

    @GetMapping
    public List<Pedido> getAll() { return service.listarTodos(); }

    @PostMapping
    public ResponseEntity<Pedido> add(@RequestBody Pedido pedido) {
        Pedido nuevo = service.crear(pedido);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pedido> getById(@PathVariable Long id) {
        Pedido p = service.buscarPorId(id);
        return p != null ? new ResponseEntity<>(p, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("{id")
    public ResponseEntity<Pedido> delete(@PathVariable Long id) {
        return service.eliminar(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/estado/{estado}")
    public List<Pedido> getEstado(@PathVariable Estado estado) {
        return service.filtrarPorEstado(estado);
    }
}
